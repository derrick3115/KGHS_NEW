<?php
include 'includes/db.php';
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $child_name = $_POST['child_name'];

    if (empty($username) || empty($email) || empty($password) || empty($confirm_password) || empty($child_name)) {
        // Handle errors
        echo "All fields are required!";
    } elseif ($password !== $confirm_password) {
        // Handle password mismatch
        echo "Passwords do not match!";
    } elseif (username_exists($username)) {
        // Handle existing username
        echo "Username already exists!";
    } elseif (email_exists($email)) {
        // Handle existing email
        echo "Email already exists!";
    } else {
        // Register the user
        if (register_user($username, $email, $password, $child_name)) {
            echo "Registration successful!";
        } else {
            echo "Registration failed!";
        }
    }
}
?>
