<?php

include 'db.php';

// Function to sanitize user input
function sanitize_input($input) {
    global $conn;
    return $conn->real_escape_string($input);
}

// Function to register a new user
// Function to register a new user
// Function to register a new user
function register_user($username, $email, $password, $child_names, $role) {
    global $conn;

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Sanitize input
    $username = sanitize_input($username);
    $email = sanitize_input($email);
    $role = sanitize_input($role); // Make sure to sanitize the role

    // Serialize the array of child names
    $child_names_serialized = serialize($child_names);

    // SQL query to insert user data into the database
    $sql = "INSERT INTO users (username, email, password, role, child_names) VALUES ('$username', '$email', '$hashed_password', '$role', '$child_names_serialized')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // Registration successful
        return true;
    } else {
        // Registration failed
        return false;
    }
}



// Function to check if a username already exists
function username_exists($username) {
    global $conn;
    $username = sanitize_input($username);
    $result = $conn->query("SELECT id FROM users WHERE username = '$username'");
    return ($result->num_rows > 0);
}

// Function to check if an email already exists
function email_exists($email) {
    global $conn;
    $email = sanitize_input($email);
    $result = $conn->query("SELECT id FROM users WHERE email = '$email'");
    return ($result->num_rows > 0);
}

// Function to get user details by username
function get_user_by_username($username) {
    global $conn;
    $username = sanitize_input($username);
    $result = $conn->query("SELECT * FROM users WHERE username = '$username'");
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}
// functions.php

// ...

// functions.php

// ...

function check_school_director() {
    // Implement your logic to check if the user is a school director
    // For simplicity, let's assume a session variable 'role' is set to 'school_director' when logging in
    return isset($_SESSION['role']) && $_SESSION['role'] === 'school_director';
}

// ...


// Placeholder function to handle user login
function login_user($username, $password) {
    global $conn;

    // Sanitize input
    $username = sanitize_input($username);
    $password = sanitize_input($password);

    // Placeholder query to fetch user data based on the login credentials
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($query);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Set the session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        return true; // Login successful
    } else {
        return false; // Login failed
    }
}

// ...

// Function to get the list of administrators
// Function to get the list of administrators
function get_administrators() {
    global $conn;

    $administrators = array(); // Initialize an empty array to store administrators

    // Modify the query to fetch administrators from the 'users' table
    $result = $conn->query("SELECT * FROM users WHERE role = 'school_director'");

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $administrators[] = $row; // Add each administrator to the array
        }
    }

    return $administrators;
}
// ...

// Function to add a new teacher


// Function to get the list of teachers
function get_teachers() {
    global $conn;

    $teachers = array();

    // Assuming 'teacher' is the role for teachers
    $result = $conn->query("SELECT * FROM users WHERE role = 'teacher'");

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $teachers[] = $row;
        }
    }

    return $teachers;
}

// Function to add a new teacher
function add_teacher($username, $email, $password) {
    global $conn;

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Sanitize input
    $username = sanitize_input($username);
    $email = sanitize_input($email);

    // SQL query to insert teacher data into the database
    $sql = "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$hashed_password', 'teacher')";

    // Execute the query
    return $conn->query($sql);
}

// Function to update teacher information
function update_teacher($id, $username, $email) {
    global $conn;

    // Sanitize input
    $id = sanitize_input($id);
    $username = sanitize_input($username);
    $email = sanitize_input($email);

    // SQL query to update teacher data
    $sql = "UPDATE users SET username = '$username', email = '$email' WHERE id = $id AND role = 'teacher'";

    // Execute the query
    return $conn->query($sql);
}

// Function to delete a teacher
function delete_teacher($id) {
    global $conn;

    // Sanitize input
    $id = sanitize_input($id);

    // SQL query to delete a teacher
    $sql = "DELETE FROM users WHERE id = $id AND role = 'teacher'";

    // Execute the query
    return $conn->query($sql);
}

// Function to get the list of head teachers
function get_head_teachers() {
    global $conn;

    $head_teachers = array();

    // Assuming 'head_teacher' is the role for head teachers
    $result = $conn->query("SELECT * FROM users WHERE role = 'head_teacher'");

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $head_teachers[] = $row;
        }
    }

    return $head_teachers;
}

// Function to add a new head teacher
function add_head_teacher($username, $email, $password) {
    global $conn;

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Sanitize input
    $username = sanitize_input($username);
    $email = sanitize_input($email);

    // SQL query to insert head teacher data into the database
    $sql = "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$hashed_password', 'head_teacher')";

    // Execute the query
    return $conn->query($sql);
}

// Function to update head teacher information
function update_head_teacher($id, $username, $email) {
    global $conn;

    // Sanitize input
    $id = sanitize_input($id);
    $username = sanitize_input($username);
    $email = sanitize_input($email);

    // SQL query to update head teacher data
    $sql = "UPDATE users SET username = '$username', email = '$email' WHERE id = $id AND role = 'head_teacher'";

    // Execute the query
    return $conn->query($sql);
}

// Function to delete a head teacher
function delete_head_teacher($id) {
    global $conn;

    // Sanitize input
    $id = sanitize_input($id);

    // SQL query to delete a head teacher
    $sql = "DELETE FROM users WHERE id = $id AND role = 'head_teacher'";

    // Execute the query
    return $conn->query($sql);
}

// Function to sanitize user input



// Function to get the list of all users
function get_all_users() {
    global $conn;

    $users = array();

    $result = $conn->query("SELECT * FROM users");

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }

    return $users;
}

// Function to add a new user
function add_user($username, $email, $password, $role, $child_names = null) {
    global $conn;

    // Check if the role is 'parent' and set child_names accordingly
    $child_names_serialized = ($role === 'parent') ? serialize($child_names) : null;

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, email, password, role, child_names) VALUES ('$username', '$email', '$hashed_password', '$role', '$child_names_serialized')";

    if ($conn->query($sql) === TRUE) {
        return true; // Addition successful
    } else {
        return false; // Addition failed
    }
}

// Function to update a user's information
// Function to update user information
error_log("Error description: " . $conn->error);

// ...

// Function to update a user's information
function update_user($id, $username, $email, $role, $child_names) {
    global $conn;

    // Sanitize input
    $id = sanitize_input($id);
    $username = sanitize_input($username);
    $email = sanitize_input($email);
    $role = sanitize_input($role);

    // SQL query to update user data
    $sql = "UPDATE users SET username = '$username', email = '$email', role = '$role', child_names = '$child_names' WHERE id = $id";

    // Execute the query
    return $conn->query($sql);
}

// ...




// Function to toggle the active status of a user
// Function to toggle the active status of a user
function toggle_user_active($id, $active) {
    global $conn;

    $sql = "UPDATE users SET active=$active WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        return true; // Update successful
    } else {
        return false; // Update failed
    }
}


// Function to delete a user
function delete_user($id) {
    global $conn;

    $sql = "DELETE FROM users WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        return true; // Deletion successful
    } else {
        return false; // Deletion failed
    }
}
// Add this function to get user by ID
// Add this function to get user by ID
function get_user_by_id($id) {
    global $conn; // Assuming $conn is your MySQLi connection object
    
    $id = sanitize_input($id); // Sanitize input

    $query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    
    if ($stmt) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        return $user;
    } else {
        return null; // Handle the case where the prepared statement fails
    }
}
// Function to get notifications for a user
function get_user_notifications($userId) {
    global $conn;
    $query = "SELECT * FROM notifications WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}


// Update your existing `update_user` function to include the `active` field

function is_serialized($data) {
    
    // if it isn't a string, it isn't serialized
    if (!is_string($data)) {
        return false;
    }
    $data = trim($data);
    if ('N;' == $data) {
        return true;
    }
    if (!preg_match('/^([adObis]):/', $data, $badions)) {
        return false;
    }
    switch ($badions[1]) {
        case 'a':
        case 'O':
        case 's':
            if (preg_match("/^{$badions[1]}:[0-9]+:.*[;}]\$/s", $data)) {
                return true;
            }
            break;
        case 'b':
        case 'i':
        case 'd':
            if (preg_match("/^{$badions[1]}:[0-9.E-]+;\$/", $data)) {
                return true;
            }
            break;
    }
    return false;
}
function is_serialized1($data) {
    // Check if the data is serialized
    $unserialized = @unserialize($data);
    return ($data === 'b:0;' || $unserialized !== false);
}
function getChildNamesValue($childNames)
{
    // Check if the data is serialized
    $unserialized = @unserialize($childNames);
    
    if ($childNames === 'b:0;' || $unserialized !== false) {
        // Data is serialized, implode the array
        return implode(', ', unserialize($childNames));
    } else {
        // Data is not serialized, use the raw string
        return $childNames;
    }
}




// Function to get all inquiries from the database
function get_all_inquiries() {
    // Replace the following code with your database query
    $inquiries = [
        ['inquiry_id' => 1, 'user_id' => 101, 'user_name' => 'John Doe', 'user_email' => 'john@example.com', 'inquiry_text' => 'Question 1'],
        ['inquiry_id' => 2, 'user_id' => 102, 'user_name' => 'Jane Doe', 'user_email' => 'jane@example.com', 'inquiry_text' => 'Question 2'],
        // Add more inquiries as needed
    ];

    return $inquiries;
}

// Function to reply to an inquiry and update the database
function reply_to_inquiry($inquiry_id, $response) {
    // Replace the following code with your database update query
    // For example, using PDO
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=your_database", "your_username", "your_password");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("UPDATE inquiries SET response = :response WHERE inquiry_id = :inquiry_id");
        $stmt->bindParam(':response', $response, PDO::PARAM_STR);
        $stmt->bindParam(':inquiry_id', $inquiry_id, PDO::PARAM_INT);

        $stmt->execute();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

// includes/functions.php

// Function to send a query and store it in the database
function send_query($sender_id, $recipient_id, $query_text, $conn) {
    // Replace the following code with your database insert query
    // For example, using PDO
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=your_database", "your_username", "your_password");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("INSERT INTO queries (user_id, query_text) VALUES (:user_id, :query_text)");
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':query_text', $query_text, PDO::PARAM_STR);

        $stmt->execute();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
// includes/functions.php

// Function to get a list of users that the parent can send queries to
function get_available_recipients($parent_id) {
    // Replace the following code with your database query
    // For example, using PDO
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=your_database", "your_username", "your_password");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $pdo->prepare("SELECT user_id, username FROM users WHERE role = 'school_director' OR role = 'teacher'");
        $stmt->bindParam(':parent_id', $parent_id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

// Placeholder function to get classes for a head teacher
function get_classes_for_head_teacher($headTeacherId) {
    global $conn;

    // Replace this query with your actual database query to get classes for the head teacher
    $query = "SELECT * FROM classes WHERE head_teacher_id = $headTeacherId";
    $result = $conn->query($query);

    $classes = array();
    while ($row = $result->fetch_assoc()) {
        $classes[] = $row;
    }

    return $classes;
}

// Inside functions.php

// Function to get queries for the head teacher
function get_queries_for_head_teacher($headTeacherId) {
    global $conn;
    $sql = "SELECT * FROM queries WHERE head_teacher_id = $headTeacherId";
    $result = $conn->query($sql);

    $queries = array();
    while ($row = $result->fetch_assoc()) {
        $queries[] = $row;
    }

    return $queries;
}

// Function to reply to a query
function reply_to_query($queryId, $response) {
    global $conn;
    // Implement the logic to reply to a query and update the database
}

// Add more functions based on your requirements



// Inside functions.php

// Function to get messages between two users
function get_messages($user1Id, $user2Id) {
    global $conn;
    $sql = "SELECT * FROM messages WHERE (sender_id = $user1Id AND receiver_id = $user2Id) OR (sender_id = $user2Id AND receiver_id = $user1Id) ORDER BY created_at ASC";
    $result = $conn->query($sql);

    $messages = array();
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }

    return $messages;
}

// Function to send a message
function send_message($senderId, $receiverId, $message) {
    global $conn;
    // Implement the logic to send a message and update the database
}
// Update online status on login
function user_login($user_id) {
    $query = "UPDATE users SET online_status = 1 WHERE id = $user_id";
    sendQuery($query);
}

// Update online status on logout
function user_logout($user_id) {
    $query = "UPDATE users SET online_status = 0 WHERE id = $user_id";
    sendQuery($query);
}
// Get online status of users
function get_online_status() {
    $query = "SELECT id, username, online_status FROM users";
    $result = sendQuery($query);

    $onlineStatus = [];

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $onlineStatus[] = [
                'user_id' => $row['id'],
                'username' => $row['username'],
                'online_status' => (bool)$row['online_status']
            ];
        }
    }

    return $onlineStatus;
}

// includes/functions.php

// ... (existing code)

function insertMessage($senderId, $recipientId, $messageText) {
    global $conn;

    $senderId = mysqli_real_escape_string($conn, $senderId);
    $recipientId = mysqli_real_escape_string($conn, $recipientId);
    $messageText = mysqli_real_escape_string($conn, $messageText);

    $query = "INSERT INTO messages (sender_id, recipient_id, message_text) VALUES ('$senderId', '$recipientId', '$messageText')";
    return sendQuery($query);
}

// functions.php

function getMessages($userId, $recipientId) {
    global $conn;

    $query = "SELECT * FROM messages WHERE (sender_id = '$userId' AND receiver_id = '$recipientId') OR (sender_id = '$recipientId' AND receiver_id = '$userId') ORDER BY timestamp";
    
    $result = sendQuery($query);

    $messages = [];

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $messages[] = [
                'sender_id' => $row['sender_id'],
                'message_text' => $row['message'],
                'timestamp' => $row['timestamp'],
            ];
        }
    }

    return $messages;
}

/**
 * Add an announcement to the database.
 *
 * @param int $senderId The ID of the sender (head teacher in this case).
 * @param string $message The announcement message.
 * @return bool True if the announcement was added successfully, false otherwise.
 */
function add_announcement($senderId, $message)
{
    global $conn;

    try {
        // Insert announcement into the database
        $stmt = $conn->prepare("INSERT INTO announcements (sender_id, message) VALUES (?, ?)");
        $stmt->bind_param("is", $senderId, $message);

        // Execute the statement
        $result = $stmt->execute();

        // Close the statement
        $stmt->close();

        return $result;
    } catch (Exception $e) {
        // Log or handle the exception as needed
        return false;
    }
}





// Function to get user role name
function get_role_name($roleId) {
    global $conn;
    
    // Check if $roleId is null
    if ($roleId === null) {
        return null;
    }

    $query = "SELECT role_name FROM roles WHERE id = ?";
    $stmt = $conn->prepare($query);
    
    if (!$stmt) {
        // Handle the error gracefully
        error_log("Failed to prepare statement: " . $conn->error);
        return null;
    }

    $stmt->bind_param('i', $roleId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $roleData = $result->fetch_assoc();
        return $roleData['role_name'];
    } else {
        // Handle the case where no role is found
        return null;
    }
}




// Function to get all appointments for a user
function get_user_appointments($userId) {
    global $conn; // Replace with your actual connection logic
    $query = "SELECT * FROM appointments WHERE scheduled_for = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $userId);  // Assuming scheduled_for is an integer, adjust the type accordingly
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($stmt->execute()) { // Check if execution was successful
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC); // Use mysqli_stmt::get_result and fetch_all
    } else {
        // error_log("Failed to get user appointments: " . $stmt->error_info());
        error_log("Failed to get user appointments: " . mysqli_error($conn));
        return []; // Handle error gracefully
    }
}


// Function to get all appointments for scheduling by a user
function get_scheduling_appointments($userId) {
    global $conn; // Replace with your actual connection logic
    $query = "SELECT id, scheduled_by, scheduled_for, scheduled_date, status FROM appointments WHERE scheduled_by = ? AND status = 'pending'";

    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $userId);

    $stmt->execute();

    // Bind result variables
    $stmt->bind_result($resultId, $resultUserId, $resultScheduledFor, $resultScheduledDateTime, $resultStatus);

    // Fetch the results
    $results = [];
    while ($stmt->fetch()) {
        $results[] = [
            'id' => $resultId,
            'scheduled_by' => $resultUserId,
            'scheduled_for' => $resultScheduledFor,
            'scheduled_date_time' => $resultScheduledDateTime,
            'status' => $resultStatus,
            // Include any other needed columns using their corresponding result variable names
        ];
    }

    return $results;
}




// Function to get all appointments for a specific role (school_director, head_teacher, teacher)
function get_role_appointments($roleId) {
    global $conn; // Replace with your actual connection logic
    $query = "SELECT * FROM appointments WHERE scheduled_for = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $roleId); // Use mysqli_stmt::bind_param for mysqli connection
    $stmt->execute();

    if ($stmt->execute()) { // Check if execution was successful
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC); // Use mysqli_stmt::get_result and fetch_all
    } else {
        // error_log("Failed to get role appointments: " . $stmt->error_info());
        error_log("Failed to get role appointments: " . mysqli_error($conn));
        return []; // Handle error gracefully
    }
}



function update_appointment_status($requestId, $status) {
    global $conn;

    $query = "UPDATE appointment_requests SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('si', $status, $requestId);
    $stmt->execute();

    return $stmt->affected_rows > 0;
}


// Function to schedule an appointment
function schedule_appointment($scheduledBy, $teacherId, $scheduledDateTime) {
    global $conn;
  
    // Add your logic here to insert the appointment into the database
    $query = "INSERT INTO appointments (scheduled_by, scheduled_for, scheduled_date_time, status) VALUES (?, ?, ?, 'pending')";
    $stmt = $conn->prepare($query);
  
    // Check if the preparation of the statement was successful
    if (!$stmt) {
        error_log("Failed to prepare statement: " . $conn->error);
        return false;
    }
  
    // Use bind_param with adjusted types
    $stmt->bind_param('iis', $scheduledBy, $teacherId, $scheduledDateTime);
  
    // Execute the statement
    $success = $stmt->execute();
  
    // Check if the execution was successful
    if (!$success) {
        // Handle error, log failed attempt
        error_log("Failed to schedule appointment: " . $stmt->error);
    }
  
    // Close the statement
    $stmt->close();
  
    return $success; // You can adjust this based on your logic
}

  // Add this function to retrieve parent appointments
function get_parent_appointments($parentID) {
    global $conn;
    $query = "SELECT * FROM appointment_requests WHERE parent_id = ? ORDER BY scheduled_date, scheduled_time";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $parentID);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// This is a simplified example, update it based on your actual implementation
function get_available_slots() {
    global $conn; // Assuming $conn is your database connection
  
    $query = "SELECT * FROM available_slots";
    $result = $conn->query($query);
  
    $slots = array();
  
    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        // Retrieve the username based on the user_id associated with the slot
        $user = get_user_by_id($row['user_id']);
  
        // Add the username to the $row array
        $row['username'] = $user['username'];
  
        $slots[] = $row;
      }
    }
  
    return $slots;
  }


function get_user_by_name_and_role($username, $role) {
    global $conn; // Assuming $conn is your database connection

    $query = "SELECT * FROM users WHERE username = ? AND role = ?";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        die("Error in SQL query: " . $conn->error);
    }

    $stmt->bind_param('ss', $username, $role);
    $stmt->execute();

    if ($stmt->error) {
        die("Error in SQL execution: " . $stmt->error);
    }

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return false;
    }
}
// Add this function to your functions.php file
function get_user_by_usernames($username) {
    global $conn; // Assuming $conn is your database connection

    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        die("Error in SQL query: " . $conn->error);
    }

    $stmt->bind_param('s', $username);
    $stmt->execute();

    if ($stmt->error) {
        die("Error in SQL execution: " . $stmt->error);
    }

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return false;
    }
}
// includes/functions.php

function get_user_by_usernam($username) {
    global $conn; // Assuming $conn is your database connection

    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        die("Error in SQL query: " . $conn->error);
    }

    $stmt->bind_param('s', $username);
    $stmt->execute();

    if ($stmt->error) {
        die("Error in SQL execution: " . $stmt->error);
    }

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return false;
    }
}

// functions.php
function is_slot_booked($slotId, $username, $availableDate, $availableTime) {
    global $conn;

    $query = "SELECT id FROM appointment_requests WHERE
              scheduled_date = ? AND scheduled_time = ? AND
              (recipient_id = (SELECT id FROM users WHERE username = ?) OR
               parent_id = (SELECT id FROM users WHERE username = ?))";
    $stmt = $conn->prepare($query);

    $stmt->bind_param('ssss', $availableDate, $availableTime, $username, $username);
    $stmt->execute();

    $result = $stmt->get_result();

    return $result->num_rows > 0;
}


  

  
  function get_appointment_requests($userId) {
    global $conn;

    $query = "SELECT * FROM appointment_requests WHERE recipient_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $requests = array();

    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }

    return $requests;
}


  



?>
