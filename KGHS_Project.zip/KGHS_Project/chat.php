<?php
session_start();
include 'includes/functions.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the current user
$user = get_user_by_id($_SESSION['user_id']);

// Get the user's contacts (teachers, head teacher, parents, etc.)
$contacts = get_user_contacts($_SESSION['user_id']);

// Select a contact to chat with
$selectedContactId = isset($_GET['contact_id']) ? $_GET['contact_id'] : null;
$selectedContact = get_user_by_id($selectedContactId);

// Get the messages between the current user and the selected contact
$messages = get_messages($user['id'], $selectedContact['id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="chat-container">
        <div class="contacts">
            <h3>Your Contacts</h3>
            <ul>
                <?php foreach ($contacts as $contact): ?>
                    <li><a href="chat.php?contact_id=<?php echo $contact['id']; ?>"><?php echo $contact['username']; ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="chat">
            <h3>Chat with <?php echo $selectedContact['username']; ?></h3>
            <div class="messages">
                <?php foreach ($messages as $message): ?>
                    <div class="message <?php echo $message['sender_id'] === $user['id'] ? 'sent' : 'received'; ?>">
                        <?php echo $message['message']; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <form action="send_message.php" method="post">
                <input type="hidden" name="receiver_id" value="<?php echo $selectedContact['id']; ?>">
                <textarea name="message" placeholder="Type your message..."></textarea>
                <button type="submit">Send</button>
            </form>
        </div>
    </div>
</body>
</html>
