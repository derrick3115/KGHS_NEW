-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2023 at 09:16 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kghs_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `sender_id`, `message`, `created_at`) VALUES
(1, 6, 'welcome', '2023-12-19 16:42:51'),
(2, 6, 'sup', '2023-12-19 17:08:01');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `scheduled_by` int(11) NOT NULL,
  `scheduled_for` int(11) DEFAULT NULL,
  `scheduled_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `scheduled_by`, `scheduled_for`, `scheduled_date`, `status`) VALUES
(1, 2, NULL, '2023-12-30 11:30:00', 'pending'),
(2, 2, NULL, '2023-12-30 11:30:00', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `appointment_requests`
--

CREATE TABLE `appointment_requests` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `recipient_id` int(11) DEFAULT NULL,
  `scheduled_date` date DEFAULT NULL,
  `scheduled_time` time DEFAULT NULL,
  `status` enum('pending','approved','declined') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment_requests`
--

INSERT INTO `appointment_requests` (`id`, `parent_id`, `recipient_id`, `scheduled_date`, `scheduled_time`, `status`, `created_at`) VALUES
(1, 3, 2, '2023-12-30', '11:30:00', 'approved', '2023-12-24 20:08:04');

-- --------------------------------------------------------

--
-- Table structure for table `approved_appointments`
--

CREATE TABLE `approved_appointments` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `recipient_id` int(11) DEFAULT NULL,
  `scheduled_date` date DEFAULT NULL,
  `scheduled_time` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `approved_appointments`
--

INSERT INTO `approved_appointments` (`id`, `parent_id`, `recipient_id`, `scheduled_date`, `scheduled_time`, `created_at`) VALUES
(1, 3, 4, '2023-12-30', '19:30:00', '2023-12-14 17:58:20'),
(2, 3, 7, '2023-12-22', '10:30:00', '2023-12-14 18:23:22'),
(3, 3, 2, '2023-12-31', '13:01:00', '2023-12-14 20:02:15'),
(4, 1, 6, '2023-12-23', '10:00:00', '2023-12-19 18:12:08'),
(5, 1, 2, '2023-12-23', '11:00:00', '2023-12-19 18:59:53'),
(6, 3, 2, '2024-01-01', '11:00:00', '2023-12-24 18:35:08'),
(7, 3, 2, '2023-12-30', '11:30:00', '2023-12-24 20:08:42');

-- --------------------------------------------------------

--
-- Table structure for table `available_slots`
--

CREATE TABLE `available_slots` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `available_date` date DEFAULT NULL,
  `available_time_from` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `available_slots`
--

INSERT INTO `available_slots` (`id`, `user_id`, `available_date`, `available_time_from`, `created_at`) VALUES
(2, 2, '2023-12-30', '11:30:00', '2023-12-24 20:09:46');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender_id`, `receiver_id`, `message`, `status`, `created_at`) VALUES
(1, 4, 1, 'hello', 'pending', '2023-12-07 11:23:40'),
(2, 1, 4, 'hello', 'pending', '2023-12-07 11:24:53'),
(3, 1, 4, 'how are you', 'pending', '2023-12-07 11:31:16'),
(4, 4, 1, 'good', 'pending', '2023-12-07 11:31:55'),
(5, 1, 4, 'salut', 'pending', '2023-12-07 11:50:01'),
(6, 1, 4, 'cava?', 'pending', '2023-12-07 11:57:21'),
(7, 4, 1, 'bien', 'pending', '2023-12-07 11:57:44'),
(8, 1, 4, 'oui', 'pending', '2023-12-07 12:09:31'),
(9, 4, 1, 'ready for hollidays?', 'pending', '2023-12-07 12:10:42'),
(10, 3, 7, 'hello', 'pending', '2023-12-14 20:03:51'),
(11, 7, 3, 'hello', 'pending', '2023-12-14 20:04:56'),
(12, 1, 2, 'sup', 'pending', '2023-12-19 11:28:43'),
(13, 2, 1, 'sup', 'pending', '2023-12-19 11:28:59'),
(14, 6, 1, 'hello philemon', 'pending', '2023-12-19 14:39:45'),
(15, 1, 6, 'hello lecture', 'pending', '2023-12-19 14:40:06'),
(16, 3, 7, 'when holidays will end ?', 'pending', '2023-12-24 18:01:36'),
(17, 7, 3, 'around 15-20 of 2024 January', 'pending', '2023-12-24 18:02:22');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` enum('unread','read') NOT NULL DEFAULT 'unread',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `status`, `created_at`) VALUES
(1, 3, 'Your appointment request for 2023-12-30 at 19:30:00 has been approved', 'unread', '2023-12-14 17:58:20'),
(2, 4, 'An appointment with you for 2023-12-30 at 19:30:00 has been approved', 'unread', '2023-12-14 17:58:20'),
(3, 3, 'Your appointment request for 2023-12-22 at 10:30:00 has been approved', 'unread', '2023-12-14 18:23:22'),
(4, 7, 'An appointment with you for 2023-12-22 at 10:30:00 has been approved', 'unread', '2023-12-14 18:23:22'),
(5, 1, 'Your appointment request for 2023-12-30 at 13:00:00 has been approved', 'unread', '2023-12-14 20:02:15'),
(6, 7, 'An appointment with you for 2023-12-30 at 13:00:00 has been approved', 'unread', '2023-12-14 20:02:15'),
(7, 1, 'Your appointment request for 2023-12-23 at 10:00:00 has been approved', 'unread', '2023-12-19 18:12:08'),
(8, 6, 'An appointment with you for 2023-12-23 at 10:00:00 has been approved', 'unread', '2023-12-19 18:12:08'),
(9, 1, 'Your appointment request for 2023-12-23 at 11:00:00 has been approved', 'unread', '2023-12-19 18:59:53'),
(10, 2, 'An appointment with you for 2023-12-23 at 11:00:00 has been approved', 'unread', '2023-12-19 18:59:53'),
(11, 3, 'Your appointment request for 2024-01-01 at 11:00:00 has been approved', 'unread', '2023-12-24 18:35:08'),
(12, 2, 'An appointment with you for 2024-01-01 at 11:00:00 has been approved', 'unread', '2023-12-24 18:35:08'),
(13, 3, 'Your appointment request for 2023-12-30 at 11:30:00 has been approved', 'unread', '2023-12-24 20:08:42'),
(14, 2, 'An appointment with you for 2023-12-30 at 11:30:00 has been approved', 'unread', '2023-12-24 20:08:42');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`) VALUES
(1, 'parent'),
(2, 'school_director'),
(3, 'head_teacher'),
(4, 'teacher');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `child_names` text NOT NULL,
  `online_status` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `child_names`, `online_status`) VALUES
(1, 'philemon', 'philemon@gmail.com', '$2y$10$nKuYt3VlzuALdvFnDpDiyO4vQSq/TSsx3YaoSt4aRHaCKAiDsmeMy', 'parent', '2023-12-05 18:52:09', '', 0),
(2, 'derrick', 'derrick@gmail.com', '$2y$10$nKuYt3VlzuALdvFnDpDiyO4vQSq/TSsx3YaoSt4aRHaCKAiDsmeMy', 'school_director', '2023-12-05 18:53:24', '', 0),
(3, 'jimmy', 'jimy@gmail.com', '$2y$10$nKuYt3VlzuALdvFnDpDiyO4vQSq/TSsx3YaoSt4aRHaCKAiDsmeMy', 'parent', '2023-12-06 11:00:49', 's:10:\"emmy,diane\";', 0),
(4, 'james', 'james@gmail.com', '$2y$10$4O7lvUVHMnlO9pGLW.8pgepulJ4xmCYp83POu1DjBtxvuzgtxBB.y', 'head_teacher', '2023-12-06 11:50:00', '', 0),
(5, 'denis', 'denis@gmail.com', '$2y$10$dl9tfFcav2Lhfu3c0xaezOpTudOfkxlIHFTdzuBT6yE4t1lzS0ItW', 'teacher', '2023-12-06 11:50:53', '', 0),
(6, 'mussa', 'moussa@gmail.com', '$2y$10$EBm2.qwF5koeWLc.p4uvn.hKbt9DUg4nfZyMSuYTW6MRuUfihA/MO', 'teacher', '2023-12-06 16:27:21', '', 0),
(7, 'prince', 'prince@gmail.com', '$2y$10$loSKN/CkdQSzQLJbK7HrnOlfH6bb3izfyoSEWn0dgbI36WCa9s9Lq', 'head_teacher', '2023-12-08 12:07:55', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `scheduled_by` (`scheduled_by`),
  ADD KEY `scheduled_for` (`scheduled_for`);

--
-- Indexes for table `appointment_requests`
--
ALTER TABLE `appointment_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `recipient_id` (`recipient_id`);

--
-- Indexes for table `approved_appointments`
--
ALTER TABLE `approved_appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `recipient_id` (`recipient_id`);

--
-- Indexes for table `available_slots`
--
ALTER TABLE `available_slots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointment_requests`
--
ALTER TABLE `appointment_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `approved_appointments`
--
ALTER TABLE `approved_appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `available_slots`
--
ALTER TABLE `available_slots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`scheduled_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`scheduled_for`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `appointment_requests`
--
ALTER TABLE `appointment_requests`
  ADD CONSTRAINT `appointment_requests_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `appointment_requests_ibfk_2` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `approved_appointments`
--
ALTER TABLE `approved_appointments`
  ADD CONSTRAINT `approved_appointments_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `approved_appointments_ibfk_2` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `available_slots`
--
ALTER TABLE `available_slots`
  ADD CONSTRAINT `available_slots_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
