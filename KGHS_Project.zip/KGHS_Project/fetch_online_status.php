<?php
// fetch_online_status.php

// Include necessary files and configurations
session_start();
include 'includes/db.php';  // Adjust the path as needed
include 'includes/functions.php';  // Adjust the path as needed

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 403 Forbidden');
    exit();
}

// Get the online status of users
$onlineStatus = get_online_status();

// Return the online status as JSON
header('Content-Type: application/json');
echo json_encode(['recipients' => $onlineStatus]);
?>
