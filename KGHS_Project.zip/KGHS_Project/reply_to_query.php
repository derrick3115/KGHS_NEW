<?php
session_start();
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $queryId = $_POST['query_id'];
    $response = $_POST['response'];

    // Call the function to reply to the query
    reply_to_query($queryId, $response);
}

// Redirect back to the head teacher dashboard after replying
header("Location: head_teacher_dashboard.php");
exit();
?>
