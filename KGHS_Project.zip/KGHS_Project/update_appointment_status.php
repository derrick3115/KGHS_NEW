<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';

// Check if request method is POST and required parameters are set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['requestId'], $_POST['status'])) {
    $requestId = $_POST['requestId'];
    $status = $_POST['status'];

    // Get the appointment details by ID
    $request = get_appointment_by_id($requestId);

    // Update the status in the appointment_requests table
    if (update_appointment_status($requestId, $status)) {
        echo "Appointment status updated successfully!";

        // Insert notification for the parent
        $parentNotificationMessage = "Your appointment request for " . $request['scheduled_date'] . " at " . $request['scheduled_time'] . " has been " . $status;
        insert_notification($request['parent_id'], $parentNotificationMessage);

        // Insert notification for the recipient (if there is one)
        if (!empty($request['recipient_id'])) {
            $recipientNotificationMessage = "An appointment with you for " . $request['scheduled_date'] . " at " . $request['scheduled_time'] . " has been " . $status;
            insert_notification($request['recipient_id'], $recipientNotificationMessage);
        }
        // Call the saving function
  save_to_approved_appointments($request);

  // Call the deleting function
  delete_from_available_slots($request);
    } else {
        echo "Failed to update appointment status. Please try again.";
    }
} else {
    echo "Invalid request: Some parameters are missing.";
}

// Function to get appointment details by ID
function get_appointment_by_id($requestId) {
    global $conn;
    $query = "SELECT * FROM appointment_requests WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $requestId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Function to insert a notification
function insert_notification($userId, $message) {
    global $conn;
    $query = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('is', $userId, $message);
    $stmt->execute();
    $stmt->close();
}

// Function to save appointment data in approved_appointments
function save_to_approved_appointments($request) {
    global $conn;
    
    // Assuming approved_appointments structure is similar to appointment_requests
    $query = "INSERT INTO approved_appointments (parent_id, recipient_id, scheduled_date, scheduled_time) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('iiss', $request['parent_id'], $request['recipient_id'], $request['scheduled_date'], $request['scheduled_time']);
    $stmt->execute();
    $stmt->close();
}

// Function to delete the schedule from available_slots
function delete_from_available_slots($request) {
    global $conn;
    
    $query = "DELETE FROM available_slots WHERE user_id = ? AND available_date = ? AND available_time_from = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('iss', $request['recipient_id'], $request['scheduled_date'], $request['scheduled_time']);
    $stmt->execute();
    $stmt->close();
}

?>
