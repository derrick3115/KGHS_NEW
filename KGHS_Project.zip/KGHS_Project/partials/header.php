<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kigali Greater Heights School</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <div class="container">
            <img src="https://www.kghs.rw/wp-content/uploads/2021/04/KGHS-PNG-logo-1.png" alt="KGHS Logo">
            <h1>Kigali Greater Heights School</h1>
            <nav>
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Academics</a>
                <a href="#">Contact</a>
            </nav>
        </div>
    </header>
    <main>
