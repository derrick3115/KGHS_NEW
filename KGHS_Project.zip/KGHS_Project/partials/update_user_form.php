<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Add your styles here for better design */
        .dashboard-container {
            max-width: 800px;
            margin: auto;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input, select {
            margin-bottom: 10px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h2>Update User</h2>
        </div>

        <div class="content">
            <!-- Update user form with pre-filled values -->
            <form method="post">
                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                
                <label for="username">Username:</label>
                <input type="text" name="username" value="<?php echo $user['username']; ?>" required>
                
                <label for="email">Email:</label>
                <input type="email" name="email" value="<?php echo $user['email']; ?>" required>
                
                <label for="role">Role:</label>
                <select name="role" required>
                    <option value="teacher" <?php echo ($user['role'] === 'teacher') ? 'selected' : ''; ?>>Teacher</option>
                    <option value="head_teacher" <?php echo ($user['role'] === 'head_teacher') ? 'selected' : ''; ?>>Head Teacher</option>
                    <option value="school_director" <?php echo ($user['role'] === 'school_director') ? 'selected' : ''; ?>>School Director</option>
                    <option value="parent" <?php echo ($user['role'] === 'parent') ? 'selected' : ''; ?>>Parent</option>
                </select>
                
                <?php if ($user['role'] === 'parent'): ?>
                    <label for="child_names">Child Names:</label>
                    <input type="text" name="child_names" value="<?php echo $user['child_names']; ?>" placeholder="Comma-separated names">
                <?php endif; ?>
                
                <label for="active">Active:</label>
                <input type="checkbox" name="active" <?php echo ($user['active'] == 1) ? 'checked' : ''; ?>>
                
                <button type="submit" name="update_user">Update User</button>
            </form>
        </div>
    </div>
</body>
</html>
