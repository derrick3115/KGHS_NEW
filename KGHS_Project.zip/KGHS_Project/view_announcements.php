<?php
// Include necessary files and start the session if needed
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

// Fetch announcements from the database
$announcements = get_announcements();

// Function to get announcements from the database
function get_announcements() {
    global $conn;
    $query = "SELECT * FROM announcements ORDER BY created_at DESC";
    $result = $conn->query($query);

    if ($result) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        return array(); // Return an empty array if there is an error
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Announcements - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('https://www.kghs.rw/wp-content/uploads/2021/04/DSC_0680-1-1-2048x1365.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        .announcements-container {
            max-width: 800px;
            margin: auto;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            flex: 1;
        }

        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }

        .announcement {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #fff;
        }

        .announcement h3 {
            color: #3498db;
        }

        .announcement p {
            color: #555;
        }

        .footer {
            background-color: #34495e;
            color: #fff;
            text-align: center;
            padding: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="announcements-container">
        <h2>View Announcements</h2>

        <?php foreach ($announcements as $announcement): ?>
            <div class="announcement">
                <p><?php echo $announcement['message']; ?></p>
                <p>Posted on: <?php echo $announcement['created_at']; ?></p>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="footer">
        &copy; 2023 KGHS. All rights reserved.
    </div>

    <?php include 'partials/footer.php'; ?>
</body>
</html>
