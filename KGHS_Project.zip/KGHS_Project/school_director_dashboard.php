<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

// Fetch notifications for the school director
$notifications = get_user_notifications($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Director Dashboard - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('https://www.kghs.rw/wp-content/uploads/2021/04/DSC_0680-1-1-2048x1365.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        .dashboard-container {
            max-width: 800px;
            margin: auto;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            flex: 1;
            position: relative;
        }

        .header {
            background-color: #3498db;
            color: #fff;
            padding: 20px;
            text-align: center;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            margin-bottom: 20px;
        }

        .content {
            padding: 20px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 10px;
        }

        p {
            color: #555;
            margin-bottom: 20px;
        }

        .actions {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .actions a, .actions button {
            text-decoration: none;
            color: #fff;
            background-color: #3498db;
            padding: 15px 30px;
            border-radius: 5px;
            transition: background-color 0.3s;
            font-size: 16px;
            cursor: pointer;
            border: none;
            outline: none;
            text-align: center;
        }

        .actions a:hover, .actions button:hover {
            background-color: #297fb8;
        }

        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            margin-top: 20px;
        }

        /* Notification Panel Styles */
        .notification-panel {
            position: absolute;
            top: 10px;
            right: 10px;
            max-width: 300px;
            background-color: #fff;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: none;
            transition: max-height 0.5s;
            overflow: hidden;
        }

        .notification-panel h3 {
            margin-bottom: 10px;
            cursor: pointer;
            color: #333;
        }

        .notification-item {
            margin-bottom: 10px;
            color: #333;
        }

        .notification-toggle {
            position: absolute;
            top: -20px;
            right: -30px;
            cursor: pointer;
            font-size: 40px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <h2>Welcome to School Director Dashboard</h2>
        </div>

        <div class="content">
            <p>Manage school administration, reply to inquiries, and approve appointments.</p>

            <div class="actions">
                <a href="manage_administration.php">Manage Administration</a>
                <a href="view_schedule.php">View Appointments</a>
                <a href="view_announcements.php">View Announcements</a>
                <a href="scheduler.php">Set Scheduler</a>
                
                <a href="send_query.php">Access Messaging</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>

        <!-- Notification Panel Toggle Button -->
        <div class="notification-toggle" onclick="toggleNotificationPanel()">🔔</div>

       <!-- Notification Panel Toggle Button -->
    <div class="notification-toggle" onclick="toggleNotificationPanel()">🔔</div>

<!-- Notification Panel -->
<div class="notification-panel" id="notificationPanel">
    <h3>Notifications</h3>
    <?php if (count($notifications) > 0): ?>
        <?php foreach ($notifications as $notification): ?>
            <div class="notification-item"><?php echo $notification['message']; ?></div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No new notifications.</p>
    <?php endif; ?>
</div>

    

    <script>
        // Function to toggle the notification panel visibility
        function toggleNotificationPanel() {
            var panel = document.getElementById("notificationPanel");
            panel.style.display = panel.style.display === "none" ? "block" : "none";
        }

        // Function to redirect to the messaging page
        function redirectToMessaging() {
            window.location.href = 'send_query.php';
        }
         // Function to toggle the notification panel visibility
         function toggleNotificationPanel() {
            var panel = document.getElementById("notificationPanel");
            panel.style.display = panel.style.display === "none" ? "block" : "none";
        }
    </script>
</body>
<?php include 'partials/footer.php'; ?>
</html>
