<?php
// session_start();
// include 'includes/db.php';
// include 'includes/functions.php';

// // Check if the appointment ID is provided in the URL
// if (isset($_GET['id'])) {
//     $appointmentId = $_GET['id'];

//     // Get appointment details
//     $appointment = get_appointment_details($appointmentId);

//     if ($appointment) {
//         // Display appointment details
//         echo '<h2>Select Appointment</h2>';
//         echo 'Appointment ID: ' . $appointment['id'] . '<br>';
//         echo 'Teacher ID: ' . $appointment['teacher_id'] . '<br>';
//         echo 'Status: ' . $appointment['status'] . '<br>';
//         echo 'Appointment Time: ' . $appointment['appointment_time'] . '<br>';
//         echo 'Created At: ' . $appointment['created_at'] . '<br>';

//         // Add a form or additional logic to allow the parent to confirm or decline the appointment
//     } else {
//         echo '<p>Appointment not found.</p>';
//     }
// } else {
//     echo '<p>Appointment ID not provided.</p>';
// }
?>
