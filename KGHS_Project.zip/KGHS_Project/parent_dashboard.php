<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';
include 'partials/header.php';

// Fetch notifications for the logged-in user
$userNotifications = get_user_notifications($_SESSION['user_id']);
// Count the number of notifications
$notificationCount = count($userNotifications);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parent Dashboard - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('https://www.kghs.rw/wp-content/uploads/2021/04/DSC_0680-1-1-2048x1365.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        .dashboard-container {
            max-width: 800px;
            margin: auto;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            flex: 1;
            position: relative; /* Added position relative for absolute positioning */
        }

        h2 {
            color: #333;
            text-align: center;
        }

        p {
            color: #555;
            text-align: center;
            margin-bottom: 20px;
        }

        .actions {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        a {
            text-decoration: none;
            color: #fff;
            background-color: #3498db;
            padding: 10px 20px;
            border-radius: 5px;
            margin: 0 10px;
            transition: background-color 0.3s;
        }

        a:hover {
            background-color: #297fb8;
        }

        footer {
            background-color: #34495e;
            color: #fff;
            text-align: center;
            padding: 10px;
            margin-top: 400px; /* Added margin-top for spacing */
        }

        /* Notification Panel Styles */
        .notification-panel {
            position: absolute;
            top: 10px;
            right: 10px;
            max-width: 300px;
            background-color: #fff; /* Changed background color */
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: none; /* Hidden by default */
            transition: max-height 0.5s; /* Added smooth transition */
            overflow: hidden; /* Hide overflow content */
        }

        .notification-panel h3 {
            margin-bottom: 10px;
            cursor: pointer;
            color: #333; /* Changed text color */
        }

        .notification-item {
            margin-bottom: 10px;
            color: #333; /* Changed text color */
        }

        .notification-toggle {
            position: absolute;
            top: -20px;
            right: -30px;
            cursor: pointer;
            font-size: 40px;
            background-color: #3498db;
            color: #fff;
            border-radius: 50%;
            padding: 5px;
        }

        .notification-count {
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: red;
            color: #fff;
            border-radius: 50%;
            padding: 5px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h2>Welcome to Your Parent Dashboard</h2>
        <p>View your child's progress, send queries, and make appointments.</p>

        <div class="actions">
            <a href="send_query.php">Send Query</a>
            <a href="parent_schedule.php">Make Appointment</a>
            <a href="view_announcements.php">View Announcements</a>
            <a href="logout.php">Logout</a>
        </div>

        <!-- Notification Panel Toggle Button with Count Badge -->
        <div class="notification-toggle" onclick="toggleNotificationPanel()">🔔
            <?php if ($notificationCount > 0): ?>
                <div class="notification-count"><?php echo $notificationCount; ?></div>
            <?php endif; ?>
        </div>

        <!-- Notification Panel -->
        <div class="notification-panel" id="notificationPanel">
            <h3>Notifications</h3>
            <?php foreach ($userNotifications as $notification): ?>
                <div class="notification-item">
                    <?php echo $notification['message']; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <footer>&copy; 2023 KGHS</footer>

    <script>
        // Function to toggle the notification panel visibility
        function toggleNotificationPanel() {
            var panel = document.getElementById("notificationPanel");
            panel.style.display = panel.style.display === "none" ? "block" : "none";
        }
    </script>
</body>
</html>