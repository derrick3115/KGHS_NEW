<?php
// get_messages.php

session_start();
include 'includes/db.php'; // Include your database connection file
include 'includes/functions.php';

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'error' => 'User not logged in']);
        exit;
    }

    $userId = $_SESSION['user_id'];
    $recipientId = $_GET['recipient_id'];

    // Use prepared statements to prevent SQL injection
    $query = "SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        echo json_encode(['success' => false, 'error' => 'Error preparing statement']);
        exit;
    }

    $stmt->bind_param('iiii', $userId, $recipientId, $recipientId, $userId);
    $stmt->execute();
    
    $result = $stmt->get_result();

    if ($result) {
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = [
                'sender_id' => $row['sender_id'],
                'message_text' => $row['message'],
                'created_at' => $row['created_at']
                // Add other fields as needed
            ];
        }
        echo json_encode(['success' => true, 'messages' => $messages]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Error fetching messages']);
    }

    $stmt->close();
    exit;
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit;
}
?>
