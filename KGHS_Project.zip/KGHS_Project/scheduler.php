<?php
session_start();
include 'includes/db.php';
include 'includes/functions.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the role name if available, otherwise set to an empty string
$roleName = isset($_SESSION['role_id']) ? get_role_name($_SESSION['role_id']) : '';

// Check if the user is not a parent
if ($roleName == 'parent') {
    header("Location: login.php");
    exit();
}

// Retrieve user details
$user = get_user_by_id($_SESSION['user_id']);

// Handle form submission for setting availability
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule_date'], $_POST['schedule_time'])) {
    $scheduleDate = $_POST['schedule_date'];
    $scheduleTime = $_POST['schedule_time'];

    // Add your logic to store the availability in the database
    // Use the user's ID, $user['id'], to associate the availability with the user

    $query = "INSERT INTO appointments (scheduled_by, scheduled_for, scheduled_date, status) VALUES (?, NULL, ?, 'pending')";
    $stmt = $conn->prepare($query);

    // Use temporary variables to hold values
    $tempScheduleDate = $scheduleDate . ' ' . $scheduleTime;

    $stmt->bind_param('is', $user['id'], $tempScheduleDate);

    if ($stmt->execute()) {
        echo "Availability set successfully!";
    } else {
        echo "Failed to set availability. Please try again.";
    }
}
// Handle form submission for setting availability
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule_date'], $_POST['schedule_time'])) {
    $scheduleDate = $_POST['schedule_date'];
    $scheduleTime = $_POST['schedule_time'];

    // Add your logic to store the availability in the "available_slots" table
    $query = "INSERT INTO available_slots (user_id, available_date, available_time_from) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);

    $stmt->bind_param('iss', $user['id'], $scheduleDate, $scheduleTime);

    if ($stmt->execute()) {
        echo "Availability set successfully!";
    } else {
        echo "Failed to set availability. Please try again.";
    }
}






// Get appointments for the user
$userAppointments = get_user_appointments($user['id']);

// Get appointments for scheduling by the user
$schedulingAppointments = get_scheduling_appointments($user['id']);

// Get appointments for the user's role
$roleAppointments = get_role_appointments($user['role']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($roleName); ?> Scheduler - KGHS</title>
    <link rel="stylesheet" href="css/styles.css">
    <!-- Include any additional styling or calendar library here -->
    <!-- Ensure you have proper scripts for calendar functionality -->
</head>

<body>
    <div class="dashboard-container">
        <div class="header">
            <h2>Welcome, <?php echo $user['username']; ?>!</h2>
        </div>

        <div class="content">
            <h3>Your Appointments</h3>
            <ul class="appointment-list">
                <?php foreach ($userAppointments as $appointment): ?>
                    <li>
                        <?php echo "Date: {$appointment['scheduled_date']}, Status: {$appointment['status']}"; ?>
                    </li>
                <?php endforeach; ?>
            </ul>

            <h3>Scheduling Appointments</h3>
            <ul class="appointment-list">
            <?php foreach ($userAppointments as $appointment): ?>
    <li>
        <?php if (isset($appointment['scheduled_date'])): ?>
            <?php echo "Date: {$appointment['scheduled_date']}, Status: {$appointment['status']}"; ?>
        <?php else: ?>
            <?php echo "Invalid appointment data"; ?>
        <?php endif; ?>
    </li>
<?php endforeach; ?>

            </ul>

            <h3><?php echo ucfirst($roleName); ?> Appointments</h3>
            <ul class="appointment-list">
                <?php foreach ($roleAppointments as $appointment): ?>
                    <li>
                        <?php echo "Date: {$appointment['scheduled_date']}, Status: {$appointment['status']}"; ?>
                        <?php if ($roleName != 'parent' && $appointment['status'] == 'pending'): ?>
                            <a href="approve_decline.php?appointment_id=<?php echo $appointment['id']; ?>&action=approve">Approve</a>
                            <a href="approve_decline.php?appointment_id=<?php echo $appointment['id']; ?>&action=decline">Decline</a>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>

            <!-- Form for setting availability -->
            <h3>Set Availability</h3>
            <form method="post" action="">
                <label for="schedule_date">Date:</label>
                <input type="date" id="schedule_date" name="schedule_date" required>
                <br>
                <label for="schedule_time">Time:</label>
                <input type="time" id="schedule_time" name="schedule_time" required>
                <br>
                <input type="submit" class="submit-btn" value="Set Availability">
            </form>
        </div>
    </div>

    <!-- Add any additional scripts for calendar functionality if needed -->

</body>

</html>
